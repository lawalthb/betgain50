<div class="dark:text-white-dark text-center flex justify-center items-center absolute bottom-0 w-screen -ml-7 py-5 px-3">
    <p>© <span id="footer-year">2022</span>. Must be 18+ to register or play. Please gamble responsibly. Licensed and authorised by BCLB under licence No. 0000454. | Developed by Talosmart</p>
</div>



@include('components.common.footer_scripts')